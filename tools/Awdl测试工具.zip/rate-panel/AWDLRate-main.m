// AWDL 速率面板 —— 隔空投送实时传输速率
//
// 只做一件事：每秒读一次 awdl0 的累计字节，算出瞬时速率并画曲线，
// 顺带列出驱动里的 ITLAWDLCoex* 计数器。不含任何诊断功能。
//
// 数据来源与 diag/xfer.sh 完全一致：
//   netstat -I awdl0 -b -n                    取 Ibytes / Obytes（第 2 行，链路层那行）
//   ioreg -p IOService -n Root -d 1 -l -w0    取 ITLAWDLCoex* 属性

#import <Cocoa/Cocoa.h>

static const CGFloat kHeaderH   = 46;
static const CGFloat kPad       = 16;
static const CGFloat kCardGap   = 12;
static const CGFloat kStatsH    = 128;
static const CGFloat kCountersH = 127;
static const NSUInteger kWindow = 180;   // 曲线保留秒数

// MARK: - 颜色

static NSColor *InColor(void) {
    return [NSColor colorWithSRGBRed:0.16 green:0.55 blue:0.85 alpha:1.0];
}
static NSColor *OutColor(void) {
    return [NSColor colorWithSRGBRed:0.92 green:0.50 blue:0.16 alpha:1.0];
}

// 采样间隔自检用的累加器
static double gDtSum = 0, gDtMin = 1e9, gDtMax = 0;
static int gDtN = 0;

// MARK: - 外部命令

static NSString *RunTask(NSString *path, NSArray<NSString *> *args) {
    NSTask *task = [[NSTask alloc] init];
    task.executableURL = [NSURL fileURLWithPath:path];
    task.arguments = args;
    NSPipe *pipe = [NSPipe pipe];
    task.standardOutput = pipe;
    task.standardError = [NSFileHandle fileHandleWithNullDevice];
    NSError *err = nil;
    if (![task launchAndReturnError:&err]) {
        return nil;
    }
    NSData *data = [pipe.fileHandleForReading readDataToEndOfFile];
    [task waitUntilExit];
    if (!data) return nil;
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

// 读 awdl0 累计字节。返回 NO 表示接口不存在或读不到。
static BOOL ReadTraffic(unsigned long long *inBytes, unsigned long long *outBytes) {
    NSString *out = RunTask(@"/usr/sbin/netstat", @[@"-I", @"awdl0", @"-b", @"-n"]);
    if (out.length == 0) return NO;

    NSMutableArray<NSString *> *lines = [NSMutableArray array];
    for (NSString *s in [out componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        if (s.length > 0) [lines addObject:s];
    }
    // 第 0 行表头；第 1 行是链路层（真实字节）；第 2 行是 IPv6（带 "-"，不能用）
    if (lines.count < 2) return NO;

    NSMutableArray<NSString *> *cols = [NSMutableArray array];
    for (NSString *t in [lines[1] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]) {
        if (t.length > 0) [cols addObject:t];
    }
    if (cols.count < 10) return NO;

    // Name Mtu Network Address Ipkts Ierrs Ibytes Opkts Oerrs Obytes Coll
    unsigned long long i = strtoull([cols[6] UTF8String], NULL, 10);
    unsigned long long o = strtoull([cols[9] UTF8String], NULL, 10);
    if (inBytes)  *inBytes  = i;
    if (outBytes) *outBytes = o;
    return YES;
}

// 采样间隔自检：速率 = 字节差 / 实测间隔，所以间隔准不准直接决定峰值准不准。
// 每满 60 个采样往 /tmp/awdlrate-timing.log 追加一行统计，方便核对。
static void AppendTimingLine(int n, double sum, double mn, double mx) {
    FILE *f = fopen("/tmp/awdlrate-timing.log", "a");
    if (!f) return;
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char stamp[16];
    strftime(stamp, sizeof(stamp), "%H:%M:%S", &tmv);
    fprintf(f, "%s  n=%d  avg=%.4fs  min=%.4fs  max=%.4fs  期间累计=%.1fs\n",
            stamp, n, sum / (n > 0 ? n : 1), mn, mx, sum);
    fclose(f);
}

static NSRegularExpression *CounterRegex(void) {
    static NSRegularExpression *re;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        re = [NSRegularExpression regularExpressionWithPattern:@"\"([A-Za-z0-9_]+)\" = (\"[^\"]*\"|[^,}\\n]+)"
                                                      options:0
                                                        error:nil];
    });
    return re;
}

// 读 Root 上的 ITLAWDLCoex* / ItlwmAWDL* 属性，返回 name -> value(字符串)
static NSDictionary<NSString *, NSString *> *ReadCounters(void) {
    NSString *out = RunTask(@"/usr/sbin/ioreg",
                            @[@"-p", @"IOService", @"-n", @"Root", @"-d", @"1", @"-l", @"-w0"]);
    if (out.length == 0) return @{};

    NSMutableDictionary<NSString *, NSString *> *dict = [NSMutableDictionary dictionary];
    NSArray *matches = [CounterRegex() matchesInString:out options:0 range:NSMakeRange(0, out.length)];
    for (NSTextCheckingResult *m in matches) {
        if (m.numberOfRanges < 3) continue;
        NSString *name = [out substringWithRange:[m rangeAtIndex:1]];
        if (![name hasPrefix:@"ITLAWDLCoex"] && ![name hasPrefix:@"ItlwmAWDL"]) continue;
        if (dict[name]) continue;
        NSString *v = [[out substringWithRange:[m rangeAtIndex:2]]
                       stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (v.length >= 2 && [v hasPrefix:@"\""] && [v hasSuffix:@"\""]) {
            v = [v substringWithRange:NSMakeRange(1, v.length - 2)];
        }
        dict[name] = v;
    }
    return dict;
}

// 面板上优先显示的项（xfer.sh 关注的同一批）；不存在的跳过
static NSArray<NSString *> *PreferredCounterOrder(void) {
    return @[@"ITLAWDLCoexDataRx",
             @"ITLAWDLCoexDataTx",
             @"ITLAWDLCoexTxOK",
             @"ITLAWDLCoexDataTxErrors",
             @"ITLAWDLCoexGateHolds",
             @"ITLAWDLCoexForwardRefused",
             @"ITLAWDLCoexBaAsks",
             @"ITLAWDLCoexBaAnswers",
             @"ITLAWDLCoexBaTxStateName",
             @"ItlwmAWDLTxDropped"];
}

// MARK: - 绘制小工具

static void FillCard(NSRect r, NSColor *color) {
    NSBezierPath *p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:10 yRadius:10];
    [color setFill];
    [p fill];
}

// 在 rect 内居中放一个边长 size 的小方块（用来画状态点）
static NSRect RectCentered(NSRect rect, CGFloat size) {
    return NSMakeRect(rect.origin.x,
                      rect.origin.y + (rect.size.height - size) / 2.0,
                      size, size);
}

static NSFont *Sans(CGFloat size, NSFontWeight weight) {
    return [NSFont systemFontOfSize:size weight:weight];
}

static NSFont *Mono(CGFloat size) {
    return [NSFont monospacedSystemFontOfSize:size weight:NSFontWeightRegular];
}

static NSFont *MonoDigits(CGFloat size, NSFontWeight weight) {
    return [NSFont monospacedDigitSystemFontOfSize:size weight:weight];
}

typedef NS_ENUM(NSInteger, Align) { AlignLeft, AlignRight, AlignCenter };

// 在 rect 内垂直居中横排一行文字
static void DrawStr(NSString *s, NSRect rect, NSFont *font, NSColor *color, Align align) {
    NSMutableParagraphStyle *ps = [NSMutableParagraphStyle new];
    ps.alignment = (align == AlignRight ? NSTextAlignmentRight
                    : align == AlignCenter ? NSTextAlignmentCenter : NSTextAlignmentLeft);
    ps.lineBreakMode = NSLineBreakByTruncatingTail;
    NSDictionary *attrs = @{NSFontAttributeName: font,
                            NSForegroundColorAttributeName: color,
                            NSParagraphStyleAttributeName: ps};
    NSSize sz = [s sizeWithAttributes:attrs];
    NSRect target = rect;
    target.size.height = MIN(rect.size.height, sz.height + 2);
    target.origin.y = rect.origin.y + (rect.size.height - target.size.height) / 2.0;
    [s drawInRect:target withAttributes:attrs];
}

// MARK: - 面板

@interface RatePanel : NSView
@property (nonatomic) BOOL running;
@property (nonatomic) BOOL ifaceOK;
@property (nonatomic, strong) NSButton *toggleButton;
@property (nonatomic, strong) NSButton *clearButton;
- (void)startSampling;
- (void)stopSampling;
- (void)clearStats;
@end

@implementation RatePanel {
    NSMutableArray<NSNumber *> *_inHist;
    NSMutableArray<NSNumber *> *_outHist;

    unsigned long long _prevIn;
    unsigned long long _prevOut;
    BOOL _hasPrev;

    double _totalIn;
    double _totalOut;
    double _peakIn;
    double _peakOut;
    double _sampledSeconds;        // 累计采样时长（实测 dt 之和）
    double _activeSeconds;         // 其中真正在传数据的时长（两个方向共用）
    NSDate *_lastSampleAt;
    NSDate *_startedAt;

    NSDictionary<NSString *, NSString *> *_counters;
    NSDictionary<NSString *, NSNumber *> *_baseline;

    NSTimer *_tickTimer;
    NSTimer *_counterTimer;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _inHist = [NSMutableArray array];
        _outHist = [NSMutableArray array];
        _counters = @{};
        _baseline = @{};
        _ifaceOK = YES;

        self.toggleButton = [NSButton buttonWithTitle:@"暂停" target:self action:@selector(toggle:)];
        self.toggleButton.bezelStyle = NSBezelStyleRounded;
        self.toggleButton.controlSize = NSControlSizeSmall;
        self.toggleButton.font = Sans(11, NSFontWeightRegular);
        [self addSubview:self.toggleButton];

        self.clearButton = [NSButton buttonWithTitle:@"清零" target:self action:@selector(clear:)];
        self.clearButton.bezelStyle = NSBezelStyleRounded;
        self.clearButton.controlSize = NSControlSizeSmall;
        self.clearButton.font = Sans(11, NSFontWeightRegular);
        [self addSubview:self.clearButton];
    }
    return self;
}

- (void)dealloc {
    [_tickTimer invalidate];
    [_counterTimer invalidate];
}

- (void)layout {
    [super layout];
    CGFloat w = self.bounds.size.width;
    CGFloat bh = 21;
    CGFloat cy = (kHeaderH - bh) / 2.0;
    self.clearButton.frame = NSMakeRect(w - kPad - 58, cy, 58, bh);
    self.toggleButton.frame = NSMakeRect(w - kPad - 58 - 8 - 58, cy, 58, bh);
}

// MARK: 采样

- (void)startSampling {
    if (_tickTimer) return;
    if (!_startedAt) _startedAt = [NSDate date];
    self.running = YES;
    self.toggleButton.title = @"暂停";

    unsigned long long i = 0, o = 0;
    _hasPrev = ReadTraffic(&i, &o);
    // 继续采样时清掉上次的时间戳：否则「暂停 5 分钟 → 继续」的第一个间隔
    // 会被算成 300 秒，那一秒的速率被摊成接近 0，还会把这 300 秒灌进时长里
    _lastSampleAt = nil;
    if (_hasPrev) {
        _prevIn = i;
        _prevOut = o;
        self.ifaceOK = YES;
    } else {
        self.ifaceOK = NO;
    }

    _tickTimer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_tickTimer forMode:NSRunLoopCommonModes];

    [self refreshCountersResettingBaseline:(_baseline.count == 0)];
    _counterTimer = [NSTimer timerWithTimeInterval:5.0 target:self selector:@selector(refreshCountersTimer) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_counterTimer forMode:NSRunLoopCommonModes];
}

- (void)stopSampling {
    self.running = NO;
    self.toggleButton.title = @"继续";
    [_tickTimer invalidate];
    _tickTimer = nil;
    [_counterTimer invalidate];
    _counterTimer = nil;
    [self setNeedsDisplay:YES];
}

- (void)clearStats {
    [_inHist removeAllObjects];
    [_outHist removeAllObjects];
    _totalIn = 0;
    _totalOut = 0;
    _peakIn = 0;
    _peakOut = 0;
    _sampledSeconds = 0;
    _activeSeconds = 0;
    _lastSampleAt = nil;
    _startedAt = self.running ? [NSDate date] : nil;
    _baseline = @{};
    [self refreshCountersResettingBaseline:YES];
    [self setNeedsDisplay:YES];
}

- (void)refreshCountersTimer {
    [self refreshCountersResettingBaseline:NO];
}

- (void)refreshCountersResettingBaseline:(BOOL)reset {
    NSDictionary<NSString *, NSString *> *now = ReadCounters();
    if (reset || _baseline.count == 0) {
        NSMutableDictionary<NSString *, NSNumber *> *b = [NSMutableDictionary dictionary];
        for (NSString *k in now) {
            NSScanner *sc = [NSScanner scannerWithString:now[k]];
            double d = 0;
            if ([sc scanDouble:&d] && sc.isAtEnd) b[k] = @(d);
        }
        _baseline = b;
    }
    _counters = now;
    [self setNeedsDisplay:YES];
}

- (void)tick {
    unsigned long long i = 0, o = 0;
    if (!ReadTraffic(&i, &o)) {
        self.ifaceOK = NO;
        _hasPrev = NO;
        _lastSampleAt = nil;
        [self setNeedsDisplay:YES];
        return;
    }
    self.ifaceOK = YES;

    // 用实测间隔算速率：Timer 会被主线程卡住，真实间隔不总是 1.000 秒
    NSDate *now = [NSDate date];
    double dt = _lastSampleAt ? [now timeIntervalSinceDate:_lastSampleAt] : 1.0;
    if (dt < 0.05) dt = 0.05;
    _lastSampleAt = now;

    // 间隔自检累加（只统计真实相邻两次采样，每 60 个写一行）
    gDtSum += dt;
    if (dt < gDtMin) gDtMin = dt;
    if (dt > gDtMax) gDtMax = dt;
    gDtN++;
    if (gDtN >= 60) {
        AppendTimingLine(gDtN, gDtSum, gDtMin, gDtMax);
        gDtSum = 0; gDtMin = 1e9; gDtMax = 0; gDtN = 0;
    }

    if (_hasPrev) {
        double dIn = (i >= _prevIn) ? (double)(i - _prevIn) : 0;
        double dOut = (o >= _prevOut) ? (double)(o - _prevOut) : 0;
        double mIn = dIn / 1048576.0 / dt;
        double mOut = dOut / 1048576.0 / dt;

        [_inHist addObject:@(mIn)];
        [_outHist addObject:@(mOut)];
        if (_inHist.count > kWindow) {
            [_inHist removeObjectsInRange:NSMakeRange(0, _inHist.count - kWindow)];
            [_outHist removeObjectsInRange:NSMakeRange(0, _outHist.count - kWindow)];
        }
        _totalIn += dIn / 1048576.0;
        _totalOut += dOut / 1048576.0;
        _sampledSeconds += dt;
        // 只有这一秒真的搬了数据（两个方向合计 > 64KB）才算「传输时间」，
        // 零星的控制包和挂着不动的那些秒都不计入
        if (dIn + dOut > 65536) _activeSeconds += dt;
        _peakIn = MAX(_peakIn, mIn);
        _peakOut = MAX(_peakOut, mOut);
    }
    _prevIn = i;
    _prevOut = o;
    _hasPrev = YES;

    [self setNeedsDisplay:YES];
}

- (void)toggle:(id)sender {
    if (self.running) [self stopSampling];
    else [self startSampling];
}

- (void)clear:(id)sender {
    [self clearStats];
}

// 仅用于 --render 自检：塞一批模拟数据，好看清曲线和布局
// 刻意做成「传两段、中间空着」，用来核对有效均速和全程均速的差别
- (void)loadDemoData {
    _startedAt = [NSDate date];
    self.running = YES;
    for (int i = 0; i < 180; i++) {
        double a = 0, b = 0;
        BOOL active = (i < 40) || (i >= 120 && i < 150);
        if (active) {
            double t = i / 9.0;
            a = 18.0 + 3.0 * sin(t) + ((i * 37) % 11 - 5) * 0.4;
            b = a * 0.35 + ((i * 53) % 7 - 3) * 0.2;
            if (a < 0) a = 0;
            if (b < 0) b = 0;
        }
        [_inHist addObject:@(a)];
        [_outHist addObject:@(b)];
        _totalIn += a;
        _totalOut += b;
        _sampledSeconds += 1;
        if ((a + b) * 1048576.0 > 65536) _activeSeconds += 1;
        _peakIn = MAX(_peakIn, a);
        _peakOut = MAX(_peakOut, b);
    }
    _counters = @{@"ITLAWDLCoexDataRx": @"2148",
                  @"ITLAWDLCoexDataTx": @"4211",
                  @"ITLAWDLCoexTxOK": @"39717",
                  @"ITLAWDLCoexDataTxErrors": @"0",
                  @"ITLAWDLCoexGateHolds": @"154",
                  @"ITLAWDLCoexForwardRefused": @"0",
                  @"ITLAWDLCoexBaAsks": @"12",
                  @"ITLAWDLCoexBaAnswers": @"11",
                  @"ITLAWDLCoexBaTxStateName": @"on",
                  @"ItlwmAWDLTxDropped": @"0"};
    _baseline = @{@"ITLAWDLCoexDataRx": @2048,
                  @"ITLAWDLCoexDataTx": @4160,
                  @"ITLAWDLCoexTxOK": @39650,
                  @"ITLAWDLCoexDataTxErrors": @0,
                  @"ITLAWDLCoexGateHolds": @154,
                  @"ITLAWDLCoexForwardRefused": @0,
                  @"ITLAWDLCoexBaAsks": @9,
                  @"ITLAWDLCoexBaAnswers": @9,
                  @"ItlwmAWDLTxDropped": @0};
    [self setNeedsDisplay:YES];
}

// MARK: 绘制

- (void)drawRect:(NSRect)dirtyRect {
    [[NSColor windowBackgroundColor] setFill];
    NSRectFill(self.bounds);

    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;

    CGFloat y = [self drawHeaderFrom:0 width:w];
    y = [self drawRatesFrom:y width:w];
    y = [self drawChartFrom:y width:w bottom:h];
    y = [self drawStatsFrom:y width:w];
    [self drawCountersFrom:y width:w bottom:h];
}

- (CGFloat)drawHeaderFrom:(CGFloat)top width:(CGFloat)w {
    NSRect area = NSMakeRect(kPad, top, w - 2 * kPad, kHeaderH);
    NSImage *icon = [[NSImage imageWithSystemSymbolName:@"dot.radiowaves.left.and.right"
                               accessibilityDescription:nil]
                     imageWithSymbolConfiguration:
                     [NSImageSymbolConfiguration configurationWithHierarchicalColor:InColor()]];
    if (icon) {
        NSRect ir = NSMakeRect(area.origin.x, area.origin.y + (kHeaderH - 15) / 2.0, 15, 15);
        [icon drawInRect:ir];
    } else {
        DrawStr(@"◉", NSMakeRect(area.origin.x, area.origin.y, 16, kHeaderH),
                Sans(12, NSFontWeightMedium), InColor(), AlignLeft);
    }

    NSRect titleRect = NSMakeRect(area.origin.x + 22, area.origin.y,
                                  area.size.width - 22, kHeaderH);
    DrawStr(@"AWDL 速率面板", titleRect, Sans(13, NSFontWeightSemibold),
            [NSColor labelColor], AlignLeft);

    // 右侧：状态点 + 时长（按钮由子视图绘制，这里只画文字）
    CGFloat rightEdge = w - kPad - 58 - 8 - 58 - 8;   // 让开两个按钮
    NSSize txtSize = NSMakeSize(180, kHeaderH);
    NSRect statusRect = NSMakeRect(rightEdge - txtSize.width, top, txtSize.width, kHeaderH);

    NSRect dot = RectCentered(statusRect, 7);
    dot.origin.x = statusRect.origin.x;
    NSColor *dc = self.ifaceOK ? [NSColor systemGreenColor] : [NSColor systemOrangeColor];
    [dc setFill];
    [[NSBezierPath bezierPathWithOvalInRect:dot] fill];

    NSRect labelRect = NSMakeRect(statusRect.origin.x + 12, top,
                                  statusRect.size.width - 12, kHeaderH);
    NSString *st = self.ifaceOK ? @"awdl0 就绪" : @"awdl0 未就绪";
    DrawStr([NSString stringWithFormat:@"%@ · 运行 %@", st, [self elapsedText]],
            labelRect, Sans(11, NSFontWeightRegular), [NSColor secondaryLabelColor], AlignLeft);

    return top + kHeaderH;
}

- (double)currentIn {
    return _inHist.count ? _inHist.lastObject.doubleValue : 0;
}
- (double)currentOut {
    return _outHist.count ? _outHist.lastObject.doubleValue : 0;
}

- (CGFloat)drawRatesFrom:(CGFloat)top width:(CGFloat)w {
    CGFloat cardH = 92;
    CGFloat cardW = (w - 2 * kPad - kCardGap) / 2.0;
    NSRect left = NSMakeRect(kPad, top, cardW, cardH);
    NSRect right = NSMakeRect(kPad + cardW + kCardGap, top, cardW, cardH);

    [self drawRateCard:left title:@"接收（入）" arrow:@"↓" value:[self currentIn] color:InColor()];
    [self drawRateCard:right title:@"发送（出）" arrow:@"↑" value:[self currentOut] color:OutColor()];

    return top + cardH + 14;
}

- (void)drawRateCard:(NSRect)r title:(NSString *)title arrow:(NSString *)arrow
               value:(double)value color:(NSColor *)color {
    FillCard(r, [NSColor controlBackgroundColor]);

    NSRect titleRect = NSMakeRect(r.origin.x + 14, r.origin.y + 10, r.size.width - 28, 16);
    NSColor *tc = (value > 0.005) ? color : [NSColor secondaryLabelColor];
    DrawStr([NSString stringWithFormat:@"%@  %@", arrow, title], titleRect,
            Sans(11, NSFontWeightMedium), tc, AlignLeft);

    NSRect numRect = NSMakeRect(r.origin.x + 14, r.origin.y + 32, r.size.width - 90, 48);
    NSColor *nc = (value > 0.005) ? color : [NSColor tertiaryLabelColor];
    DrawStr([NSString stringWithFormat:@"%.2f", value], numRect,
            MonoDigits(42, NSFontWeightSemibold), nc, AlignLeft);

    NSRect unitRect = NSMakeRect(r.origin.x + r.size.width - 76, r.origin.y + 52, 62, 20);
    DrawStr(@"MB/s", unitRect, Sans(11, NSFontWeightMedium),
            [NSColor secondaryLabelColor], AlignRight);
}

- (CGFloat)drawChartFrom:(CGFloat)top width:(CGFloat)w bottom:(CGFloat)bottom {
    // chart 吃掉剩余空间；统计与计数器固定高度
    CGFloat chartH = bottom - top - 22 - 14 - (kStatsH + 14) - (kCountersH + kPad);
    chartH = MAX(chartH, 150);

    // 标题行
    NSRect headRect = NSMakeRect(kPad, top, w - 2 * kPad, 16);
    NSString *caption = [NSString stringWithFormat:@"最近 %lu 秒", (unsigned long)kWindow];
    DrawStr(caption, headRect, Sans(11, NSFontWeightMedium),
            [NSColor secondaryLabelColor], AlignLeft);

    CGFloat lx = kPad + [caption sizeWithAttributes:@{NSFontAttributeName: Sans(11, NSFontWeightMedium)}].width + 16;
    [self drawLegendAt:NSMakePoint(lx, top + 3) color:InColor() text:@"入"];
    [self drawLegendAt:NSMakePoint(lx + 40, top + 3) color:OutColor() text:@"出"];

    NSRect hintRect = NSMakeRect(kPad, top, w - 2 * kPad, 16);
    DrawStr(@"每秒一个点", hintRect, Sans(10, NSFontWeightRegular),
            [NSColor tertiaryLabelColor], AlignRight);

    CGFloat chartTop = top + 22;
    NSRect box = NSMakeRect(kPad, chartTop, w - 2 * kPad, chartH);
    NSBezierPath *boxPath = [NSBezierPath bezierPathWithRoundedRect:box xRadius:8 yRadius:8];
    [[[NSColor textBackgroundColor] colorWithAlphaComponent:0.45] setFill];
    [boxPath fill];

    NSRect plot = NSInsetRect(box, 8, 6);
    [self drawPlot:plot];

    return chartTop + chartH + 14;
}

- (void)drawLegendAt:(NSPoint)p color:(NSColor *)c text:(NSString *)t {
    NSRect bar = NSMakeRect(p.x, p.y + 6, 12, 2.5);
    [c setFill];
    NSRectFill(bar);
    DrawStr(t, NSMakeRect(p.x + 15, p.y, 20, 15), Sans(10, NSFontWeightRegular),
            [NSColor secondaryLabelColor], AlignLeft);
}

- (void)drawPlot:(NSRect)plot {
    double maxVal = 0;
    for (NSNumber *n in _inHist)  maxVal = MAX(maxVal, n.doubleValue);
    for (NSNumber *n in _outHist) maxVal = MAX(maxVal, n.doubleValue);
    double yMax = MAX(1.0, ceil(maxVal * 1.2));

    CGFloat padTop = 14, padBottom = 5;
    CGFloat plotH = plot.size.height - padTop - padBottom;
    if (plotH < 10) return;

    // 横向网格
    for (int i = 0; i <= 4; i++) {
        CGFloat yy = plot.origin.y + padTop + plotH * i / 4.0;
        NSBezierPath *p = [NSBezierPath bezierPath];
        [p moveToPoint:NSMakePoint(plot.origin.x, yy)];
        [p lineToPoint:NSMakePoint(NSMaxX(plot), yy)];
        [[NSColor colorWithCalibratedWhite:0.5 alpha:(i == 4 ? 0.30 : 0.12)] setStroke];
        [p setLineWidth:1];
        [p stroke];
    }
    // 每 30 秒竖线
    CGFloat stepX = plot.size.width / (CGFloat)(kWindow - 1);
    for (NSUInteger k = 1; k * 30 < kWindow; k++) {
        CGFloat xx = NSMaxX(plot) - (CGFloat)(k * 30) * stepX;
        NSBezierPath *p = [NSBezierPath bezierPath];
        [p moveToPoint:NSMakePoint(xx, plot.origin.y + padTop)];
        [p lineToPoint:NSMakePoint(xx, plot.origin.y + padTop + plotH)];
        [[NSColor colorWithCalibratedWhite:0.5 alpha:0.10] setStroke];
        [p setLineWidth:1];
        [p stroke];
    }

    // 上限标注
    DrawStr([NSString stringWithFormat:@"%.1f MB/s", yMax],
            NSMakeRect(plot.origin.x + 2, plot.origin.y, 80, padTop),
            Mono(9.5), [NSColor tertiaryLabelColor], AlignLeft);

    NSUInteger n = MIN(_inHist.count, kWindow);
    if (n < 2) return;
    NSUInteger base = _inHist.count - n;
    CGFloat baseY = plot.origin.y + padTop + plotH;

    NSBezierPath *pin = [NSBezierPath bezierPath];
    NSBezierPath *pout = [NSBezierPath bezierPath];

    for (NSUInteger j = 0; j < n; j++) {
        CGFloat x = NSMaxX(plot) - (CGFloat)(n - 1 - j) * stepX;
        double vi = _inHist[base + j].doubleValue;
        double vo = _outHist[base + j].doubleValue;
        CGFloat yi = baseY - plotH * (CGFloat)MIN(MAX(vi / yMax, 0.0), 1.0);
        CGFloat yo = baseY - plotH * (CGFloat)MIN(MAX(vo / yMax, 0.0), 1.0);
        NSPoint pi = NSMakePoint(x, yi);
        NSPoint po = NSMakePoint(x, yo);
        if (j == 0) {
            [pin moveToPoint:pi];
            [pout moveToPoint:po];
        } else {
            [pin lineToPoint:pi];
            [pout lineToPoint:po];
        }
    }

    // 入方向淡填充：从最后一个采样点垂到底边，再回到第一个采样点的 x
    CGFloat firstX = NSMaxX(plot) - (CGFloat)(n - 1) * stepX;
    NSBezierPath *fill = [NSBezierPath bezierPath];
    [fill appendBezierPath:pin];
    [fill lineToPoint:NSMakePoint(NSMaxX(plot), baseY)];
    [fill lineToPoint:NSMakePoint(firstX, baseY)];
    [fill closePath];
    [[InColor() colorWithAlphaComponent:0.12] setFill];
    [fill fill];

    [pout setLineWidth:1.5];
    [OutColor() setStroke];
    [pout stroke];

    [pin setLineWidth:1.8];
    [InColor() setStroke];
    [pin stroke];
}

- (CGFloat)drawStatsFrom:(CGFloat)top width:(CGFloat)w {
    CGFloat cardH = kStatsH;
    NSRect r = NSMakeRect(kPad, top, w - 2 * kPad, cardH);
    FillCard(r, [NSColor controlBackgroundColor]);

    NSRect titleRect = NSMakeRect(r.origin.x + 14, r.origin.y + 10, 100, 14);
    DrawStr(@"统计", titleRect, Sans(11, NSFontWeightSemibold),
            [NSColor secondaryLabelColor], AlignLeft);

    CGFloat labelX = r.origin.x + 14;
    CGFloat colInX   = r.origin.x + 90;
    CGFloat colOutX  = r.origin.x + 210;
    CGFloat colWidth = 110;
    CGFloat startY   = r.origin.y + 32;
    CGFloat rowH     = 19;

    // 表头
    DrawStr(@"入", NSMakeRect(colInX, startY, colWidth, rowH), Sans(10, NSFontWeightBold), InColor(), AlignLeft);
    DrawStr(@"出", NSMakeRect(colOutX, startY, colWidth, rowH), Sans(10, NSFontWeightBold), OutColor(), AlignLeft);

    // 均速只用「真正在搬数据的时长」做分母 —— 挂着不传的那些秒不算进去
    double avgIn = _activeSeconds > 0.05 ? _totalIn / _activeSeconds : 0;
    double avgOut = _activeSeconds > 0.05 ? _totalOut / _activeSeconds : 0;

    NSArray *names = @[@"均速", @"峰值", @"合计", @"时长"];
    NSArray *inVals = @[[NSString stringWithFormat:@"%.2f MB/s", avgIn],
                        [NSString stringWithFormat:@"%.2f MB/s", _peakIn],
                        [NSString stringWithFormat:@"%.1f MB", _totalIn],
                        [NSString stringWithFormat:@"%.0f 秒", _activeSeconds]];
    NSArray *outVals = @[[NSString stringWithFormat:@"%.2f MB/s", avgOut],
                         [NSString stringWithFormat:@"%.2f MB/s", _peakOut],
                         [NSString stringWithFormat:@"%.1f MB", _totalOut],
                         @""];

    for (NSUInteger i = 0; i < names.count; i++) {
        CGFloat yy = startY + rowH * (i + 1);
        DrawStr(names[i], NSMakeRect(labelX, yy, 70, rowH),
                Sans(11, NSFontWeightRegular), [NSColor secondaryLabelColor], AlignLeft);
        DrawStr(inVals[i], NSMakeRect(colInX, yy, colWidth, rowH),
                Mono(11), [NSColor labelColor], AlignLeft);
        DrawStr(outVals[i], NSMakeRect(colOutX, yy, colWidth, rowH),
                Mono(11), [NSColor labelColor], AlignLeft);
    }

    // 右侧说明：讲清「均速」的分母是什么
    CGFloat noteX = r.origin.x + 340;
    NSColor *noteColor = [NSColor tertiaryLabelColor];
    DrawStr(@"均速 = 合计 ÷ 时长", NSMakeRect(noteX, startY + rowH, 300, rowH),
            Sans(10, NSFontWeightRegular), noteColor, AlignLeft);
    DrawStr(@"时长只算真正有数据在流动的秒数", NSMakeRect(noteX, startY + rowH * 2, 320, rowH),
            Sans(10, NSFontWeightRegular), noteColor, AlignLeft);
    DrawStr(@"挂着不传输的时间不计入", NSMakeRect(noteX, startY + rowH * 3, 300, rowH),
            Sans(10, NSFontWeightRegular), noteColor, AlignLeft);
    // 只写一句话太笼统，直接把峰值那一秒的原始数字摆出来：字节 ÷ 间隔 = 这个峰值
    DrawStr(@"峰值 = 那一秒的字节差 ÷ 实测间隔", NSMakeRect(noteX, startY + rowH * 4, 320, rowH),
            Sans(10, NSFontWeightRegular), noteColor, AlignLeft);

    return top + cardH + 14;
}

- (NSString *)elapsedText {
    if (!_startedAt) return @"—";
    if (!self.running) return @"已暂停";
    NSInteger sec = (NSInteger)[[NSDate date] timeIntervalSinceDate:_startedAt];
    return [NSString stringWithFormat:@"%02ld:%02ld", (long)(sec / 60), (long)(sec % 60)];
}

- (CGFloat)drawCountersFrom:(CGFloat)top width:(CGFloat)w bottom:(CGFloat)bottom {
    CGFloat cardH = bottom - top - kPad;
    if (cardH < kCountersH) cardH = kCountersH;
    NSRect r = NSMakeRect(kPad, top, w - 2 * kPad, cardH);
    FillCard(r, [NSColor controlBackgroundColor]);

    NSRect titleRect = NSMakeRect(r.origin.x + 14, r.origin.y + 10, 200, 14);
    DrawStr(@"驱动计数器", titleRect, Sans(11, NSFontWeightSemibold),
            [NSColor secondaryLabelColor], AlignLeft);

    NSRect hintRect = NSMakeRect(r.origin.x + 14, r.origin.y + 10, r.size.width - 28, 14);
    DrawStr([NSString stringWithFormat:@"每 5 秒刷新 · 绿色为增量 · 驱动共 %lu 项",
             (unsigned long)_counters.count],
            hintRect, Sans(10, NSFontWeightRegular), [NSColor tertiaryLabelColor], AlignRight);

    if (_counters.count == 0) {
        DrawStr(@"没读到 ITLAWDLCoex* 属性 —— 驱动可能未加载，或版本较旧。",
                NSMakeRect(r.origin.x + 14, r.origin.y + 34, r.size.width - 28, 18),
                Sans(11, NSFontWeightRegular), [NSColor secondaryLabelColor], AlignLeft);
        return top + cardH;
    }

    // 只显示 xfer.sh 关注的那批关键项；一个都没有（老驱动）才退回按字母序取前 10 项
    NSMutableArray<NSString *> *order = [NSMutableArray array];
    for (NSString *k in PreferredCounterOrder()) {
        if (_counters[k]) [order addObject:k];
    }
    if (order.count == 0) {
        NSMutableArray *numeric = [NSMutableArray array];
        for (NSString *k in [[_counters allKeys] sortedArrayUsingSelector:@selector(compare:)]) {
            NSString *v = _counters[k];
            if (![v isEqualToString:@"Yes"] && ![v isEqualToString:@"No"]) {
                [numeric addObject:k];
            }
        }
        NSRange rng = NSMakeRange(0, MIN((NSUInteger)10, numeric.count));
        [order addObjectsFromArray:[numeric subarrayWithRange:rng]];
    }

    CGFloat innerTop = r.origin.y + 32;
    CGFloat innerBottom = NSMaxY(r) - 10;
    CGFloat rowH = 17;
    NSInteger maxRows = (NSInteger)((innerBottom - innerTop) / rowH);
    if (maxRows < 1) maxRows = 1;

    NSInteger columns = 2;
    NSInteger perCol = maxRows;
    NSInteger capacity = (NSInteger)order.count;
    if (capacity > perCol * columns) capacity = perCol * columns;

    CGFloat colW = (r.size.width - 28) / columns;
    for (NSInteger idx = 0; idx < capacity; idx++) {
        NSInteger col = idx / perCol;
        NSInteger row = idx % perCol;
        NSString *name = order[idx];
        NSString *value = _counters[name];

        CGFloat x = r.origin.x + 14 + col * colW;
        CGFloat yy = innerTop + row * rowH;

        NSString *shortName = [name stringByReplacingOccurrencesOfString:@"ITLAWDLCoex" withString:@""];
        shortName = [shortName stringByReplacingOccurrencesOfString:@"ItlwmAWDL" withString:@""];

        DrawStr(shortName, NSMakeRect(x, yy, colW - 112, rowH),
                Mono(10.5), [NSColor secondaryLabelColor], AlignLeft);
        DrawStr(value, NSMakeRect(x + colW - 106, yy, 46, rowH),
                Mono(10.5), [NSColor labelColor], AlignRight);

        NSNumber *base = _baseline[name];
        NSScanner *sc = [NSScanner scannerWithString:value];
        double d = 0;
        if (base && [sc scanDouble:&d] && sc.isAtEnd) {
            double delta = d - base.doubleValue;
            if (fabs(delta) >= 1) {
                NSString *ds = [NSString stringWithFormat:@"%@%.0f", delta > 0 ? @"+" : @"", delta];
                NSColor *dc = delta > 0 ? [NSColor systemGreenColor] : [NSColor systemRedColor];
                DrawStr(ds, NSMakeRect(x + colW - 56, yy, 50, rowH),
                        Mono(9.5), dc, AlignRight);
            }
        }
    }

    return top + cardH;
}

@end

// MARK: - 入口

@interface AppDelegate : NSObject <NSApplicationDelegate>
@property (nonatomic, strong) NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)note {
    NSRect frame = NSMakeRect(0, 0, 880, 760);
    NSWindowStyleMask style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable |
                              NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable;
    self.window = [[NSWindow alloc] initWithContentRect:frame
                                              styleMask:style
                                                backing:NSBackingStoreBuffered
                                                  defer:NO];
    self.window.title = @"AWDL 速率面板";
    self.window.minSize = NSMakeSize(780, 700);
    self.window.releasedWhenClosed = NO;

    RatePanel *panel = [[RatePanel alloc] initWithFrame:frame];
    self.window.contentView = panel;
    [self.window center];
    [self.window makeFirstResponder:panel];
    [self.window makeKeyAndOrderFront:nil];

    [NSApp activateIgnoringOtherApps:YES];
    [panel startSampling];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    return YES;
}

@end

static void BuildMenu(void) {
    NSMenu *menubar = [NSMenu new];
    NSMenuItem *appItem = [NSMenuItem new];
    [menubar addItem:appItem];
    [NSApp setMainMenu:menubar];

    NSMenu *appMenu = [NSMenu new];
    NSString *title = @"AWDL 速率面板";
    [appMenu addItemWithTitle:[NSString stringWithFormat:@"关于 %@", title]
                       action:@selector(orderFrontStandardAboutPanel:)
                keyEquivalent:@""];
    [appMenu addItem:[NSMenuItem separatorItem]];
    [appMenu addItemWithTitle:[NSString stringWithFormat:@"隐藏 %@", title]
                       action:@selector(hide:)
                keyEquivalent:@"h"];
    [appMenu addItem:[NSMenuItem separatorItem]];
    [appMenu addItemWithTitle:[NSString stringWithFormat:@"退出 %@", title]
                       action:@selector(terminate:)
                keyEquivalent:@"q"];
    appItem.submenu = appMenu;

    NSMenuItem *winItem = [[NSMenuItem alloc] initWithTitle:@"窗口" action:nil keyEquivalent:@""];
    [menubar addItem:winItem];
    NSMenu *winMenu = [NSMenu new];
    [winMenu addItemWithTitle:@"最小化" action:@selector(performMiniaturize:) keyEquivalent:@"m"];
    [winMenu addItemWithTitle:@"关闭" action:@selector(performClose:) keyEquivalent:@"w"];
    winItem.submenu = winMenu;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        // --render <png> [--dark]：离屏渲染一张面板图，用于检查排版
        for (int i = 1; i < argc; i++) {
            if (strcmp(argv[i], "--render") != 0 || i + 1 >= argc) continue;
            NSString *path = [NSString stringWithUTF8String:argv[i + 1]];
            BOOL dark = NO;
            for (int j = i + 2; j < argc; j++) {
                if (strcmp(argv[j], "--dark") == 0) dark = YES;
            }
            [NSApplication sharedApplication];
            [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];

            RatePanel *panel = [[RatePanel alloc] initWithFrame:NSMakeRect(0, 0, 880, 760)];
            panel.appearance = [NSAppearance appearanceNamed:(dark ? NSAppearanceNameDarkAqua
                                                                     : NSAppearanceNameAqua)];
            [panel loadDemoData];
            [panel layoutSubtreeIfNeeded];

            NSBitmapImageRep *rep = [panel bitmapImageRepForCachingDisplayInRect:panel.bounds];
            [panel cacheDisplayInRect:panel.bounds toBitmapImageRep:rep];
            NSData *png = [rep representationUsingType:NSBitmapImageFileTypePNG properties:@{}];
            BOOL ok = [png writeToFile:path atomically:YES];
            printf("%s %s (%lux%lu px)\n", ok ? "已渲染" : "写入失败",
                   path.UTF8String,
                   (unsigned long)rep.pixelsWide, (unsigned long)rep.pixelsHigh);
            return ok ? 0 : 1;
        }

        // --probe：只打印一次读数，用来验证解析是否正确
        for (int i = 1; i < argc; i++) {
            if (strcmp(argv[i], "--probe") == 0) {
                unsigned long long inB = 0, outB = 0;
                if (ReadTraffic(&inB, &outB)) {
                    printf("awdl0 存在  入 %llu 字节  出 %llu 字节\n", inB, outB);
                } else {
                    printf("awdl0 不存在或读不到\n");
                }
                NSDictionary *c = ReadCounters();
                printf("计数器 %lu 项\n", (unsigned long)c.count);
                NSArray *keys = [[c allKeys] sortedArrayUsingSelector:@selector(compare:)];
                for (NSUInteger i = 0; i < MIN(keys.count, (NSUInteger)14); i++) {
                    printf("  %s = %s\n", [keys[i] UTF8String], [c[keys[i]] UTF8String]);
                }
                return 0;
            }
        }

        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        BuildMenu();

        static AppDelegate *delegate = nil;
        delegate = [AppDelegate new];
        NSApp.delegate = delegate;
        [NSApp run];
    }
    return 0;
}
